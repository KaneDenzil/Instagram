//
//  Post+CoreDataClass.swift
//  DemoInstagram
//
//  Created by Kane Denzil Quadras Bernard on 2018-04-01.
//  Copyright © 2018 Kane Denzil Quadras Bernard. All rights reserved.
//
//

import Foundation
import CoreData


public class Post: NSManagedObject {

}
