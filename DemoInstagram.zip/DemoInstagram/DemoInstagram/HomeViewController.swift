//
//  HomeViewController.swift
//  DemoInstagram
//
//  Created by Kane Denzil Quadras Bernard on 2018-04-02.
//  Copyright © 2018 Kane Denzil Quadras Bernard. All rights reserved.
//

import UIKit
import CoreData


class HomeViewController: UIViewController {

    // this is your database variable - it lets you access and manipulate the CoreData db
    let myContext = (UIApplication.shared.delegate as! AppDelegate).persistentContainer.viewContext
    
    
    // data source --> array of Category objects
    var users = [User]()
    override func viewDidLoad() {
        super.viewDidLoad()
        let username = UserDefaults.standard.value(forKey: "loginUser") as! String
        let password = UserDefaults.standard.value(forKey: "loginPassword") as! String
        loadData(username:username, password: password)
        // Do any additional setup after loading the view.
    }

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
    

    /*
    // MARK: - Navigation

    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        // Get the new view controller using segue.destinationViewController.
        // Pass the selected object to the new view controller.
    }
    */
    func loadData(username:String, password:String) {
        let request : NSFetchRequest<User> = User.fetchRequest()
        print("======================UserName=================",username)
        print("======================UserName=================",password)
        
        request.predicate = NSPredicate(format: "username == %@ && password == %@", username, password)
        
        do {
            users = try myContext.fetch(request)
            print("===================Login Data===============",users.count)
        }
        catch {
            print("An error occured: \(error)")
        }
    }

}
